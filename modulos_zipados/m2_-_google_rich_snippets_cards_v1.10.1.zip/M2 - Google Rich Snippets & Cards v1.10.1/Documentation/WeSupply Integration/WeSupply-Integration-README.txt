WeSupply Integration for Magento 2.
Code is part of the current archive and needs to be installed under below directory:
/app/code/WeSupply/Toolbox

More details in documentation, under installation section or https://wesupplylabs.com
