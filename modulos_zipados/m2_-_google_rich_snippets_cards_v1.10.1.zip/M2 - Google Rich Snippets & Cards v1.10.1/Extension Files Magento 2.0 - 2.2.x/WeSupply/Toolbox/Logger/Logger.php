<?php
/**
 * Created by PhpStorm.
 * User: adminuser
 * Date: 13.06.2019
 * Time: 15:01
 */

namespace WeSupply\Toolbox\Logger;


class Logger extends \Monolog\Logger
{

}