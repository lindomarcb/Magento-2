# MageFix-Customer

In Magento 2 you can't (for the moment) watch what your customers have in their shopping carts.
This module provides a fix to do it.


Installation
--
As usual for Magento 2 modules


Version
--
0.0.3 - Fixes a fatal error that occurs when products have options in the cart

0.0.2 - Allow products deletion

0.0.1 - Initial commit


