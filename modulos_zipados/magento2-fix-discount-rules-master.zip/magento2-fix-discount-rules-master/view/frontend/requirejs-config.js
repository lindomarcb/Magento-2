/**
 * Copyright © MagestyApps. All rights reserved.
 * See LICENSE.txt for license details.
 */

var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/select-payment-method': {
                'MagestyApps_FixRules/js/action/select-payment-method-mixin': true
            }
        }
    }
};
